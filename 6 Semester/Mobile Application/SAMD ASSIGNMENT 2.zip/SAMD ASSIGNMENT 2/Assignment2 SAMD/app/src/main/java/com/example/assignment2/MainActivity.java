package com.example.assignment2;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private TextView textView;
    private Button button1, button2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.view);
        button1 = findViewById(R.id.btn1);
        button2 = findViewById(R.id.btn2);

        button1.setOnClickListener(this);
        button2.setOnClickListener(this);

        textView.append("\nMainActivity.onCreate()");
        Log.d("MainActivity", "onCreate");
    }

    @Override
    protected void onStart() {
        super.onStart();
        textView.append("\nMainActivity.onStart()");
        Log.d("MainActivity", "onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        textView.append("\nMainActivity.onResume()");
        Log.d("MainActivity", "onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        textView.append("\nMainActivity.onPause()");
        Log.d("MainActivity", "onPause()");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        textView.append("\nMainActivity.onRestart()");
        Log.d("MainActivity", "onRestart()");
    }

    @Override
    protected void onStop() {
        super.onStop();
        textView.append("\nMainActivity.onStop()");
        Log.d("MainActivity", "onStop()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        textView.append("\nMainActivity.onDestroy()");
        Log.d("MainActivity", "onDestroy()");
    }

    private void showDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = this.getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialogbox, null);
        builder.setView(dialogView);
        AlertDialog alertDialog = builder.create();
        TextView messageView = dialogView.findViewById(R.id.dialog_message);
        messageView.setText("Dialogue Box Is Appeared:" + "Will you want to continue?");

        Button buttonYes = dialogView.findViewById(R.id.btn_yes);
        buttonYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });

        Button buttonNo = dialogView.findViewById(R.id.btn_no);
        buttonNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
                finish();
            }
        });
        alertDialog.show();
    }

    @Override
    public void onClick(View view) {
        int id=view.getId();
        if(id==R.id.btn1)
        {
            textView.append("\nShowed Dialog Box");
            showDialog();
        }

        else if(id==R.id.btn2)
        {
            Intent intent = new Intent(MainActivity.this, FullScreen.class);
            startActivity(intent);
        }
    }

}

