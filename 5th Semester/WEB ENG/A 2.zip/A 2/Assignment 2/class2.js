const EventEmitter = require('events');
class University extends EventEmitter{
    constructor()
    {
        super();
        this.on('FirstEvent',()=>{
            this.print()
        })
    }
    print()
    {
        this.emit('LastEvent',()=>{
            console.log("Complete")
        })
    }
}
module.exports = University;