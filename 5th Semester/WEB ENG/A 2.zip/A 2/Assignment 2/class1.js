var University = require("./class2");
var University_obj = new University()
var detail = function()
{
    console.log("\nUniversity Name => Bahria University");
    console.log("Campus => Karachi Campus");
    console.log("-----------------------------");
    console.log("\tDepartments");
    console.log("-----------------------------");
    console.log("    Software Engineering");
    console.log("    Computer Engineering");
    console.log("    Electrical Engineering");
    console.log("    Computer Science");
    console.log("    Information Technology");
    console.log("    BBA");







}
University_obj.on('LastEvent',detail);
University_obj.emit('FirstEvent');