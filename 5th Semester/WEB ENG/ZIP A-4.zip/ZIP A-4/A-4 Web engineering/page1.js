function func() {
    let forSharedInteger = parseInt(localStorage.getItem("Share"));
    document.getElementById("share").innerText = "" + forSharedInteger;
    if (forSharedInteger >= 0) {
        forSharedInteger++;
        localStorage.Share = forSharedInteger;
    } else {
      firstnumass();
    }
  }
  
  const firstnumass = () => {
    const Share = 0;
    localStorage.Share = Share;
    location.reload();
  };
  
  function ONLoad(){
    let forSharedInteger = parseInt(localStorage.getItem("Share"));
    document.getElementById("share").innerText = "" + forSharedInteger;
  }
  