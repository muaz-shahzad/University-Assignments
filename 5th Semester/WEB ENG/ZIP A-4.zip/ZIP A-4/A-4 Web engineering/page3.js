function func() {
  let Expiry = parseInt(localStorage.getItem("expiry"));
  
  if (Expiry) {
    let currentTime = new Date();
    console.log(currentTime.getTime());
    if (currentTime.getTime() > Expiry) {
      document.getElementById("Timer").innerText = "Session Expired.";
    } else {
      document.getElementById("Timer").innerText = "CountDown Start"
    }
  } else {
    ExpirePrior();
  }
}

const ExpirePrior = () => {
  const currentTime = new Date();
  const expiry = currentTime.getTime() + 50000;
  localStorage.expiry = expiry;
  location.reload()
};
