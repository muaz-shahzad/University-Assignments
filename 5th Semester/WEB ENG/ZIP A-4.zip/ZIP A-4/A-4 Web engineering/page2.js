function func() {
    let SecretInt = parseInt(sessionStorage.getItem("Pint"));
    document.getElementById("PrevInt").innerText = "" + SecretInt;
    if (SecretInt >= 0) {
        SecretInt++;
        sessionStorage.Pint = SecretInt;
    } else {
      Num1st();
    }
  }
  
  const Num1st = () => {
    const Pint = 0;
    sessionStorage.Pint = Pint;
    location.reload();
  };
  
  function ONLoad(){
    let SecretInt = parseInt(sessionStorage.getItem("Pint"));
    document.getElementById("PrevInt").innerText = "" + SecretInt;
  }